#!/usr/bin/expect -f

set timeout 5

set ip [ lindex $argv 0 ]
set server [ lindex $argv 1 ]


spawn ssh  quicktron@$ip -p 2223 

expect {
  "yes/no" {send "yes\r";exp_continue}
 }

expect "desktop:~$"
  send "sudo su\r"

expect "quicktron:"
  send "quicktron\r"

expect "quicktron#"
  send "cd /mnt/home/quicktron\r"

expect "quicktron#"
  send "mkdir wlan\r"

expect "quicktron#"
  send "cd wlan\r"

expect "wlan#"
  send "scp root@$server:/opt/shell/wenjian/* .\r"

expect "wlan#"
  send "chmod +x *\r"

expect "wlan#"
  send "unzip *.zip\r"

expect "wlan#"
  send "rm -rf *.zip\r"

expect "wlan#"
  send "chown -R quicktron test/\r"

expect "wlan#"
  send "chgrp -R quicktron test/\r"

expect "wlan#"
  send "cp test/quicktron /var/spool/cron/crontabs/\r"

expect "wlan#"
  send "cd /var/spool/cron/crontabs/\r"

expect "crontabs#"
  send "chmod 600 quicktron\r"

expect "crontabs#"
  send "chgrp crontab quicktron\r"

expect "crontabs#"
  send "chown quicktron quicktron\r"

expect "crontabs#"
  send "systemctl restart cron\r"

expect "crontabs#"
  send "cd /mnt/home/quicktron/wlan\r"

expect "wlan#"
  send "sed -i '/--systohc/ a /bin/bash /mnt/home/quicktron/wlan/wlancheck.sh 172.31.125.253 &' /etc/rc.local\r"

expect "wlan#"
  send "sed -i '/information./ a net.ipv6.conf.all.disable_ipv6= 1' /etc/sysctl.conf\r"

expect "wlan#"
  send "sed -i '/information./ a net.ipv6.conf.default.disable_ipv6= 1' /etc/sysctl.conf\r"

expect "wlan#"
  send "sysctl -p\r"

expect "wlan#"
  send "exit\r"

expect "desktop:~$"
  send "exit\r"

expect eof
